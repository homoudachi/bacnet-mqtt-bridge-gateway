This demo is designed for a Raspberry Pi connected to a PiFace card.

The demo uses libpifacedigital from github.com/piface repository.

To build, start with the configure script:

$ ./configure.sh
$ make clean all
