BACnet Etherent
Demonstrates the Ethernet peripheral by implmenting BACnet over Ethernet
on the RX62N Development Kit.  The project is compiled with the RX Standard
Toolchain, and the default drivers included with the RX62N kit.
 
The project does not use any additional hardware.
 
The project was tested using a BACnet/IP to BACnet Ethernet router,
using the bacnet-tools from the BACnet Protocol Stack site.
