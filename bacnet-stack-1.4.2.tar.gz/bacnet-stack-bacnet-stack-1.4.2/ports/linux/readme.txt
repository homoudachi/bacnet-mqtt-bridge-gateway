This is a port to Linux for testing.
The unit tests can be run via the test.sh script.
