/**************************************************************************
*
* Copyright (C) 2011 Steve Karg <skarg@users.sourceforge.net>
*
* SPDX-License-Identifier: MIT
*
*********************************************************************/
#ifndef HARDWARE_H
#define HARDWARE_H

#include "stm32f10x_conf.h"
#include "stm32f10x_it.h"

#define MAX_BINARY_OUTPUTS 2

#endif
