Licenses for the BACnet Stack at SourceForge

This BACnet protocol stack implementation is specifically
designed for the embedded BACnet appliance, using a GPL with
exception license (like eCos), which means that any changes
to the core code that are distributed must be made available
in accordance with section (3) of the GNU General Public License.
However, the BACnet library can be linked to proprietary code
without the proprietary code becoming GPL.

Each file that is subject to the GPL uses the following text comment
at the top of the file:

/**************************************************************************
 *
 * Copyright (C) 2005 Steve Karg
 *
 * SPDX-License-Identifier: GPL-2.0-or-later WITH GCC-exception-2.0
 *
 *********************************************************************/

The example and demo files are licensed using an MIT style
license, officially called an Expat License by GNU, and is
compatible with the GPL.  The files subject to this license
include the following text comment at the top of the file:

/**************************************************************************
*
* Copyright (C) 2005 Steve Karg <skarg@users.sourceforge.net>
*
* SPDX-License-Identifier: MIT
*
*********************************************************************/
